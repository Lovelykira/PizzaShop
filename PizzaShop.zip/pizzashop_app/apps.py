from django.apps import AppConfig


class PizzashopAppConfig(AppConfig):
    name = 'pizzashop_app'
